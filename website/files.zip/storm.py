"""The animated sand storm: 4-px grains and long gust streaks on their own pen."""
import math
import random

from config import MAX_GRAINS, PAL, STORM_TICK_MS
from gfx import rect, screen, storm
from state import state

grains = []


def new_grain(x=None):
    return [random.uniform(-400, 400) if x is None else x,
            max(-250.0, min(262.0, random.gauss(-30, 130))),   # y: thickest near the ground
            random.uniform(6, 18),                             # speed, px per tick
            random.choice((4, 4, 8)),                          # length
            random.randrange(4)]                               # colour index


def storm_gust():
    return 0.5 + 0.5 * math.sin(state["tick"] / 20.0)


def storm_level():
    return min(1.0, 0.22 + 0.09 * state["travel"] + 0.30 * storm_gust())


def render_storm():
    """One frame of blowing sand. Pure pixels: 4-px grains and long gust streaks."""
    storm.clear()
    gust, lvl = storm_gust(), storm_level()
    cols = PAL[state["pal"]]["grain"]
    if not grains:
        grains.extend(new_grain() for _ in range(MAX_GRAINS))
    for g in grains[:int(MAX_GRAINS * lvl)]:
        g[0] += g[2] * (0.7 + 1.3 * gust)
        g[1] = max(-250.0, min(262.0, g[1] + random.uniform(-2.5, 1.5)))
        if g[0] > 400:
            g[:] = new_grain(-404)
        ln = g[3] * (2 if gust > 0.55 else 1)
        rect(storm, int(g[0] // 4) * 4, int(g[1] // 4) * 4, ln, 4, cols[g[4]])
    if gust > 0.4:                                             # long streaks in a gust
        t = state["tick"]
        for k in range(int(7 * lvl)):
            x = ((t * 16 * (1 + k % 3) + k * 173) % 900) - 450
            y = -230 + (k * 83) % 460
            rect(storm, x, y, 48 + (k * 29) % 90, 2, cols[(k + 1) % 2])


def set_storm(on):
    state["storm"] = on
    if not on:
        storm.clear()


def storm_tick():
    if state["storm"]:
        state["tick"] += 1
        render_storm()
        screen.update()
    screen.ontimer(storm_tick, STORM_TICK_MS)
