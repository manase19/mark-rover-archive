"""One forward click = one animated leg of the walk.

The leg is driven by the clock, not by a frame count, so it lasts
WALK_SECONDS however fast or slow the machine redraws. While it plays,
state["travel"] slides from the previous step to the next and the odometer,
the clock and the head-bob follow it.
"""
import time

from config import (BOB_PX, CLOCKS, LEG_METERS, STRIDE_SECONDS, WALK_MSG,
                    WALK_SECONDS)
from gfx import screen, view
from render import draw_all
from state import state
from util import ease, lerp, minutes


def walk_to(n, done):
    t0 = time.monotonic()
    a_tv, a_odo, a_clk = state["travel"], state["odo"], state["clock_min"]
    b_odo, b_clk = a_odo + LEG_METERS[n], minutes(CLOCKS[n])
    state["msg"] = WALK_MSG

    def frame():
        elapsed = time.monotonic() - t0
        p = min(1.0, elapsed / WALK_SECONDS)
        e = ease(p)
        state["travel"] = lerp(a_tv, n, e)
        state["odo"] = lerp(a_odo, b_odo, e)
        state["clock_min"] = lerp(a_clk, b_clk, e)
        # dip the view on every other half-stride; settle flat when we stop
        view["dy"] = -BOB_PX if (p < 1 and int(elapsed / (STRIDE_SECONDS / 2)) % 2) else 0
        draw_all()
        if p < 1:
            screen.ontimer(frame, 1)
        else:
            done()
    frame()
