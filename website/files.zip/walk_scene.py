"""The walking scene: sky, hills, valley wall, sand, rocks and the lander behind you.

Everything is a function of state["travel"] (how far along the walk we are,
in steps), so one piece of code draws both the still frames and the walking
animation. While walking:
  * rocks and sand ripples slide toward you and get bigger (they recycle in
    a loop: whatever passes your feet reappears small on the horizon),
  * the hills and the valley wall swell and creep outward as you close in,
  * the slope climbs.
"""
import math

from config import (COLS, DEPTH_PER_STEP, HORIZON, LANDER_COL, LANDER_U, P, PAL,
                    RISE, SLOPE_HALF, SUN_COL, WORLD)
from gfx import boulder, contours, disc, layer, pen, rect
from state import state
from util import gradient, lerp, q, rnd, terrain

GROUND = 300     # how far below the horizon the nearest ground reaches (it slides under the HUD)


# ------------------------------------------------------------ view maths
def scol(wc, pan, margin=8):
    """Screen column of world column wc (a little negative = just off the left
    edge), or None when it is outside the view."""
    sc = (wc - pan) % WORLD
    if sc > WORLD - margin:
        sc -= WORLD
    return sc if sc < COLS + margin else None


def heading(wc):
    """Signed degrees away from straight ahead (-180..180)."""
    return (wc + 180) % WORLD - 180


def sample(pan, zoom):
    """World column seen at each screen column when the view is magnified by
    `zoom` about the centre of the screen."""
    mid = COLS // 2
    return [int(pan + mid + (c - mid) / zoom) % WORLD for c in range(COLS)]


def zoom_for(rate, tv, pan):
    """Magnification of a scenery layer after walking tv steps. Facing forward
    things swell as you approach; facing backward they shrink as you leave."""
    facing = math.cos(math.radians((pan + COLS // 2) % WORLD))
    return (1 + rate * tv) ** facing


def rise_at(tv):
    i = min(int(tv), len(RISE) - 2)
    return lerp(RISE[i], RISE[i + 1], min(1.0, tv - i))


# ------------------------------------------------------------ recycling depth slots
def slot(key, tv):
    """Each rock/ripple owns a slot that drifts toward the viewer as tv grows.
    Returns (cycle, p): p runs 0 (horizon) .. 1 (at your feet); when it wraps,
    cycle ticks over and the object reappears somewhere new."""
    u = rnd(key + 4) + tv * DEPTH_PER_STEP
    cyc = int(u)
    return cyc, u - cyc


def rr(key, cyc, k):
    """Stable random number for (slot, cycle, purpose)."""
    return rnd(key + k + cyc * 7919)


# ------------------------------------------------------------ lander + trail
def draw_trail(pal, cx, y0, u):
    """Footprints from the player's feet back to the lander."""
    bottom = -246
    y, k = bottom, 0
    while y < y0 - 2:
        t = (y0 - y) / float(y0 - bottom)            # 0 at the lander, 1 at the viewer
        side = -1 if k % 2 else 1
        x = cx + side * int(2 * u * (1 - t) + 22 * t)
        w, h = 4 + int(8 * t), 3 + int(3 * t)
        rect(pen, x - w // 2, y, w, h, pal["streak"])
        y += 8 + int(22 * t)
        k += 1


def draw_lander(pal, sc, n):
    """The landing craft the robot rolled out of. Hatch open, beacon dark."""
    cx = -400 + sc * P
    u = LANDER_U[n]
    y0 = min(HORIZON - 8, -150 + n * 38)
    sh = max(2, u // 2)
    metal, lit, dark, gold = "#8e8981", "#cfcac0", "#5b5650", "#c9a23e"

    draw_trail(pal, cx, y0, u)
    rect(pen, cx - 10 * u, y0 - sh, 21 * u, sh, pal["boul"][3])         # shadow

    rect(pen, cx - 18 * u, y0, 7 * u, u, "#e8dcc6")                      # parachute rags
    rect(pen, cx - 17 * u, y0 + u, 4 * u, u, "#f2e8d4")
    rect(pen, cx - 15 * u, y0 + 2 * u, 2 * u, u, "#e8dcc6")

    for k in range(5):                                                   # splayed legs
        off = int((4 + 0.9 * k) * u)
        rect(pen, cx - off - u, y0 + (4 - k) * u, u, u, metal)
        rect(pen, cx + off, y0 + (4 - k) * u, u, u, dark)
    for s in (-1, 1):                                                    # foot pads
        rect(pen, cx + s * int(8 * u) - int(1.5 * u), y0, 3 * u, sh, lit)

    for r, half in enumerate([4, 5, 5, 5, 4, 3]):                        # capsule body
        y = y0 + (4 + r) * u
        rect(pen, cx - half * u, y, 2 * half * u, u, gold if r == 1 else metal)
        rect(pen, cx - half * u, y, u, u, lit)
        rect(pen, cx + (half - 1) * u, y, u, u, dark)

    rect(pen, cx, y0 + 5 * u, 3 * u, 3 * u, "#14100e")                   # open hatch
    for k in range(5):                                                   # ramp
        rect(pen, cx + (3 + k) * u, y0 + (4 - k) * u, u, u, "#2b2624")
        rect(pen, cx + (3 + k) * u, y0 + (5 - k) * u - 2, u, 2, "#7a746c")

    rect(pen, cx - 3 * u, y0 + 10 * u, max(2, u // 2), 5 * u, lit)       # mast + dish
    rect(pen, cx - 5 * u, y0 + 15 * u, 5 * u, sh, lit)
    rect(pen, cx - 4 * u, y0 + 15 * u - sh, 3 * u, sh, metal)
    rect(pen, cx + 2 * u, y0 + 10 * u - sh, u, sh, "#5a1212")            # dead beacon


# ------------------------------------------------------------ ground clutter
def draw_ripples(pal, pan, tv, s0):
    """Sand ripples, wider up close."""
    for i in range(140):
        key = s0 + 3000 + i * 7
        cyc, p = slot(key, tv)
        sc = scol(int(rr(key, cyc, 3) * WORLD), pan)
        if sc is None:
            continue
        d = p ** 1.5
        w = int((2 + rr(key, cyc, 5) * 4) * P * (1 + 2 * d))
        c = pal["streak"] if rr(key, cyc, 6) < 0.5 else pal["sand"]
        rect(pen, -400 + sc * P, q(HORIZON - 10 - d * GROUND), w, 3 + int(d * 5), c)


def draw_rocks(pal, pan, tv, s0, lsc):
    """Scattered rocks: flat dark slabs, rounded boulders, pebbles (nearer = bigger),
    plus a few big boulders. Far rocks are drawn first."""
    items = []
    for i in range(130):
        key = s0 + 1000 + i * 13
        cyc, p = slot(key, tv)
        sc = scol(int(rr(key, cyc, 1) * WORLD), pan, 6)
        if sc is None or (lsc is not None and abs(sc - lsc) < 15):
            continue
        d = p ** 1.5
        items.append((q(HORIZON - 8 - d * GROUND), -400 + sc * P, d, 0, key, cyc))
    for i in range(16):
        key = s0 + 5000 + i * 29
        cyc, p = slot(key, tv)
        sc = scol(int(rr(key, cyc, 1) * WORLD), pan, 14)
        if sc is None or (lsc is not None and abs(sc - lsc) < 18):
            continue
        d = p ** 1.5
        items.append((q(HORIZON - 8 - d * GROUND), -400 + sc * P, d, 1, key, cyc))
    items.sort(reverse=True)

    for y, x, d, big, key, cyc in items:
        if big:                                                # big boulder
            w = 24 + int(d * (70 + 60 * rr(key, cyc, 9)))
            boulder(x, y, w, int(w * (0.5 + 0.25 * rr(key, cyc, 10))), pal["boul"])
            continue
        kind, w = rr(key, cyc, 3), int(10 + d * 64)
        if kind < 0.4:                                         # flat dark slab
            h = 3 + int(d * 7)
            rect(pen, x, y, w, h, pal["rock_d"])
            rect(pen, x + 2, y + h - 2, w * 3 // 4, 2, pal["rock_l"])
        elif kind < 0.8:                                       # rounded boulder
            boulder(x, y, w, int(w * 0.6), pal["boul"])
        else:                                                  # pebbles
            for k in range(3):
                pw = 4 + int(d * 8)
                rect(pen, x + k * (pw + 2), y + (k % 2) * 2, pw, max(3, pw // 2), pal["rock_d"])


# ------------------------------------------------------------ the scene
def draw_walk():
    pal, pan, tv = PAL[state["pal"]], state["pan"], state["travel"]
    s0 = pal["seed"]

    for i, c in enumerate(gradient(pal["sky"], 13)):          # hazy sky bands
        rect(pen, -400, 300 - (i + 1) * 20, 800, 20, c)

    sc = scol(SUN_COL, pan, 10)                                # sun, only if in view
    if sc is not None:
        cx, cy = -400 + sc * P, HORIZON + pal["sun_h"]
        disc(cx, cy, 8, pal["halo"], HORIZON)
        disc(cx, cy, 5, pal["glow"], HORIZON)
        disc(cx, cy, 3, pal["sun"], HORIZON)

    # Distant flat-topped mesas, huge soft domes, then low rolling mounds.
    # Nearer layers swell faster as you walk, which gives the parallax.
    xs = sample(pan, zoom_for(0.03, tv, pan))
    mesa = [HORIZON + (q(8 + terrain(x, 23 + s0, 90) * 22)
                       if terrain(x, 29 + s0, 30) > 0.52 else 0) for x in xs]
    layer(mesa, pal["mesa_l"], pal["mesa"], P, HORIZON)
    xs = sample(pan, zoom_for(0.07, tv, pan))
    dome = [HORIZON + q(6 + terrain(x, 11 + s0, 40) * (34 + 3 * tv)) for x in xs]
    layer(dome, pal["far_l"], pal["far"], P, HORIZON)
    xs = sample(pan, zoom_for(0.16, tv, pan))
    near = [HORIZON + q(terrain(x, 47 + s0, 10) * (12 + 2 * tv)) for x in xs]
    layer(near, pal["near_l"], pal["near"], 0, HORIZON)

    rise = rise_at(tv)                                         # the valley wall ahead
    if rise > 1:
        xs = sample(pan, zoom_for(0.10, tv, pan))
        tops = []
        for x in xs:
            t = max(0.0, 1 - abs(heading(x)) / SLOPE_HALF)
            tops.append(HORIZON + q(rise * t * t * (3 - 2 * t)
                                    * (0.9 + 0.2 * terrain(x, 61 + s0, 5))))
        layer(tops, pal["slope_l"], pal["slope"], P, HORIZON)
        contours(tops, range(20, 110, 20), pal["strata"], HORIZON)

    for i, c in enumerate(gradient(pal["ground"], 17)):       # ground bands
        rect(pen, -400, HORIZON - (i + 1) * 20, 800, 20, c)

    draw_ripples(pal, pan, tv, s0)

    lsc = scol(LANDER_COL, pan, 20)                            # only when looking back
    draw_rocks(pal, pan, tv, s0, lsc)
    if lsc is not None:
        draw_lander(pal, lsc, min(len(LANDER_U) - 1, int(round(tv))))
