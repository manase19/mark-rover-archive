"""
MARS-OPS // SENSORY LOG  -  opening sequence
Retro pixel-art horror ARG prototype. Standard library only (turtle, math, random, time).

Run:  python main.py

Controls
  click anywhere      -> walk forward (the only on-screen option)
  press B (or Down)   -> hidden: turn 180 degrees and look back at the landing
                         craft. Press again to face forward (a click also does).

Files
  main.py          entry point: wires up input and starts the story
  config.py        every constant, palette and line of text (start tweaking here)
  state.py         the one shared state dict
  util.py          maths, colour and noise helpers
  gfx.py           screen, pens and pixel-art primitives (rect, disc, layer...)
  rockface.py      angular rock: ridgelines, layered cliff faces, faceted boulders
  walk_scene.py    the walking scene (sky, hills, slope, rocks, lander)
  vista_scene.py   the canyon vista at the end
  storm.py         animated sand storm
  hud.py           top bar / message bar
  effects.py       wipe, fading text, typewriter
  render.py        composes one frame (world + HUD + storm)
  walk.py          the animated walk for one forward click
  story.py         story beats: boot, timelapse, ridge, vista, end card
  controls.py      click / key handlers
"""
import turtle

from config import STORM_TICK_MS
from controls import look_back, on_click
from gfx import screen
from story import begin
from storm import storm_tick

if __name__ == "__main__":
    screen.onscreenclick(on_click)
    screen.onkey(look_back, "b")
    screen.onkey(look_back, "Down")
    screen.listen()
    screen.ontimer(storm_tick, STORM_TICK_MS)
    begin()
    turtle.done()
