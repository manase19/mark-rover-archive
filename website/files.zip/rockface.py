"""Angular rock: jagged ridgelines, layered cliff faces and faceted boulders.

Everything here is built from straight edges and hard corners on purpose
(no discs, no ellipses), so cliffs read as broken, stratified rock rather
than round blobs.
"""
from config import COLS, P
from gfx import pen, rect
from util import q, rnd, interp, mix


def X(i):
    """Left edge (screen x) of column i."""
    return -400 + i * P


def ridge(pts, seed=0, jag=0, run=(2, 4)):
    """Blocky ridgeline. A hand-placed polyline is chopped into short flat runs,
    and each run is nudged up or down, so the silhouette is made of steps and
    hard corners instead of smooth hills. Returns one height per column."""
    out, c = [], 0
    while c < COLS:
        n = run[0] + int(rnd(c * 31 + seed) * (run[1] - run[0] + 1))
        off = (rnd(c * 17 + seed + 5) - 0.5) * jag
        for k in range(c, min(COLS, c + n)):
            out.append(q(interp(pts, k) + off))
        c += n
    return out[:COLS]


def _seam(i, j, y0, color, salt):
    """A strata seam across columns i..j, broken into short segments that dip
    a little up or down, so the layers look tilted and cracked, not ruled."""
    c = i
    while c <= j:
        n = min(2 + int(rnd(salt + c * 13) * 5), j - c + 1)
        dip = 4 * int(rnd(salt + c * 13 + 1) * 3)          # 0, 4 or 8 px
        rect(pen, X(c), y0 + dip, n * P, 3, color)
        c += n


def cliff_face(tops, floor, pal, seed=0, gullies=0, haze_h=0):
    """A stratified rock wall under the silhouette `tops` (one height per column).

    pal keys: crest, lit, high, low, dark, seam, gully, haze.
      - horizontal strata bands, lighter high up, darker low down
      - a lit cap on every crest, lit/shadowed risers on every step
      - diagonal erosion gullies running down from the crest
      - haze_h > 0 fades the base toward `haze` (aerial perspective)
    """
    top_max = max(tops)
    if top_max <= floor:
        return
    span = float(top_max - floor)

    def tone(ym, k):
        c = mix(pal["low"], pal["high"], (ym - floor) / span)
        c = mix(c, pal["dark"], 0.22) if k % 2 else mix(c, pal["lit"], 0.10)
        if haze_h and ym - floor < haze_h:
            c = mix(c, pal["haze"], 0.75 * (1 - (ym - floor) / haze_h))
        return c

    # strata: bands of uneven thickness, stacked from the floor up
    y, k = floor, 0
    while y < top_max:
        h = 4 * (4 + int(rnd(seed + k * 7) * 6))            # 16..36 px
        y0, y1 = y, y + h
        col = tone((y0 + y1) / 2.0, k)
        seam = mix(col, pal["seam"], 0.55)
        i = 0
        while i < COLS:
            if tops[i] >= y1:                               # band fully inside the rock
                j = i
                while j + 1 < COLS and tops[j + 1] >= y1:
                    j += 1
                rect(pen, X(i), y0, (j - i + 1) * P, h, col)
                _seam(i, j, y0, seam, seed * 101 + k * 17)
                i = j + 1
            elif y0 < tops[i] < y1:                         # the crest cuts through this band
                j = i
                while j + 1 < COLS and tops[j + 1] == tops[i]:
                    j += 1
                rect(pen, X(i), y0, (j - i + 1) * P, tops[i] - y0, col)
                rect(pen, X(i), y0, (j - i + 1) * P, 3, seam)
                i = j + 1
            else:
                i += 1
        y, k = y1, k + 1

    # lit cap along every crest
    i = 0
    while i < COLS:
        j = i
        while j + 1 < COLS and tops[j + 1] == tops[i]:
            j += 1
        if tops[i] > floor:
            cap = min(P, tops[i] - floor)
            rect(pen, X(i), tops[i] - cap, (j - i + 1) * P, cap, pal["crest"])
        i = j + 1

    # risers: faces that look toward the sun are lit, the others fall into shadow
    for i in range(COLS):
        t = tops[i]
        if t <= floor:
            continue
        right = tops[i + 1] if i + 1 < COLS else t
        left = tops[i - 1] if i else t
        if t - right >= P:
            b = max(right, floor)
            rect(pen, X(i) + P - 4, b, 4, t - b, pal["lit"])
        if t - left >= P:
            b = max(left, floor)
            rect(pen, X(i), b, 4, t - b, pal["dark"])

    # gullies: dark diagonal cracks that step sideways as they run down the face
    for g in range(gullies):
        c = 2 + int(rnd(seed + g * 11 + 1) * (COLS - 4))
        if tops[c] - floor < 60:
            continue
        drift = 1 if rnd(seed + g * 11 + 2) < 0.5 else -1
        length = 40 + int(rnd(seed + g * 11 + 3) * 90)
        y, col, drop = tops[c] - 8, c, 0
        while drop < length and y > floor + 8:
            nxt = max(floor, y - 24)
            if not 0 <= col < COLS or tops[col] < y:
                break
            rect(pen, X(col), nxt, P, y - nxt, pal["gully"])
            if col + 1 < COLS and tops[col + 1] >= y:
                rect(pen, X(col) + P, nxt, 3, y - nxt, pal["lit"])
            y, col, drop = nxt, col + drift, drop + 24


def chunk(x, y, w, h, cols, seed=0):
    """Angular boulder (x = left edge, y = bottom): flat top, chamfered
    shoulders and a slanted light/dark facet line. cols = (light, mid, dark, shadow)."""
    light, mid, dark, shadow = cols
    rect(pen, x - 4, y - 3, w + 8, 3, shadow)
    rows = max(3, h // 4)
    cut = 0.20 + 0.20 * rnd(seed)                  # how hard the shoulders are cut
    split = 0.36 + 0.20 * rnd(seed + 1)            # where light turns to shadow
    for r in range(rows):
        t = r / float(rows - 1)                    # 0 at the base .. 1 at the top
        inset_l = int(w * cut * max(0.0, t - 0.55) / 0.45) // 4 * 4
        inset_r = int(w * cut * 0.7 * max(0.0, t - 0.65) / 0.35) // 4 * 4
        left, right = x + inset_l, x + w - inset_r
        facet = x + int(w * (split + 0.16 * t)) // 4 * 4
        top_row = r >= rows - 2
        rect(pen, left, y + r * 4, facet - left, 4, light if top_row else mid)
        rect(pen, facet, y + r * 4, right - facet, 4, mid if top_row else dark)
