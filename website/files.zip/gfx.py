"""Screen, pens and the pixel-art drawing primitives shared by every scene."""
import turtle

from config import W, H, P, COLS

# ------------------------------------------------------------ screen + pens
screen = turtle.Screen()
screen.setup(W, H)
screen.title("MARS-OPS // SENSORY LOG")
screen.bgcolor("black")
screen.tracer(0, 0)            # we call screen.update() ourselves


def make_pen():
    t = turtle.Turtle(visible=False)
    t.penup()
    t.speed(0)
    t.setundobuffer(None)      # don't hoard undo history
    return t


pen = make_pen()    # the world (sky, ground, rocks, lander...)
ui = make_pen()     # HUD: top bar, message bar
storm = make_pen()  # animated sand storm (redrawn every tick)
fx = make_pen()     # full-screen wipes
txt = make_pen()    # overlay / typewriter text

# Vertical camera offset for the world pen only (the head-bob while walking).
view = {"dy": 0}


# ------------------------------------------------------------ primitives
def rect(t, x, y, w, h, color):
    """Solid filled rectangle with its bottom-left corner at (x, y)."""
    if t is pen:
        y += view["dy"]
    t.fillcolor(color)
    t.goto(x, y)
    t.begin_fill()
    t.goto(x + w, y)
    t.goto(x + w, y + h)
    t.goto(x, y + h)
    t.goto(x, y)
    t.end_fill()


def disc(cx, cy, r, color, floor=-999):
    """Blocky pixel disc; rows below `floor` are skipped."""
    for dy in range(-r, r + 1):
        y = cy + dy * P
        if y >= floor:
            half = int((r * r + r - dy * dy) ** 0.5)
            rect(pen, cx - half * P, y, (2 * half + 1) * P, P, color)


def layer(tops, c_top, c_body, lit=0, floor=-300):
    """Silhouette from a list of column heights (equal runs merged).
    Columns whose top is at or below `floor` are skipped."""
    i = 0
    while i < COLS:
        j = i
        while j + 1 < COLS and tops[j + 1] == tops[i]:
            j += 1
        x, w, top = -400 + i * P, (j - i + 1) * P, tops[i]
        if top > floor:
            if top - lit > floor:
                rect(pen, x, floor, w, top - lit - floor, c_body)
            if lit:
                rect(pen, x, max(floor, top - lit), w, min(lit, top - floor), c_top)
        i = j + 1


def contours(tops, offsets, color, floor, h=3):
    """Thin strata lines that follow a silhouette (they make a slope read as a slope)."""
    for off in offsets:
        i = 0
        while i < COLS:
            y = tops[i] - off
            if y <= floor:
                i += 1
                continue
            j = i
            while j + 1 < COLS and tops[j + 1] - off == y:
                j += 1
            rect(pen, -400 + i * P, y, (j - i + 1) * P, h, color)
            i = j + 1


def boulder(x, y, w, h, cols):
    """Rounded rock (x = left edge, y = bottom), drawn in 4-px rows.
    cols = (light, mid, dark, shadow)."""
    light, mid, dark, shadow = cols
    rows = max(2, h // 4)
    cx = x + w // 2
    rect(pen, x - w // 8, y - 3, w + w // 4, 3, shadow)
    for r in range(rows):
        t = (r + 0.5) / rows
        half = max(2, int(w / 2 * (1 - (2 * t - 1) ** 2) ** 0.5))
        c = light if t > 0.66 else (mid if t > 0.3 else dark)
        rect(pen, cx - half, y + r * 4, 2 * half, 4, c)
        if t <= 0.66 and half >= 6:                      # shaded right flank
            rect(pen, cx + half // 2, y + r * 4, half - half // 2, 4, dark)


def puff(x, y, w, c1="#dcb496", c2="#e8c8aa"):
    """A small wisp of blown dust."""
    rect(pen, x, y, w, 4, c1)
    rect(pen, x + 10, y + 4, max(4, w - 22), 4, c2)
    rect(pen, x + 4, y - 4, max(4, w - 18), 4, c1)
