"""Small helpers: pixel snapping, colours, polylines, deterministic noise."""
from config import WORLD, P


def q(v):
    """Snap a height to the pixel grid."""
    return int(v // P) * P


def lerp(a, b, t):
    return a + (b - a) * t


def ease(t):
    """Smoothstep: a gentle start and stop."""
    return t * t * (3 - 2 * t)


def interp(pts, x):
    """Height at x of a hand-placed polyline [(x0, y0), (x1, y1), ...]."""
    if x <= pts[0][0]:
        return pts[0][1]
    for (x0, y0), (x1, y1) in zip(pts, pts[1:]):
        if x0 <= x <= x1:
            return y0 + (y1 - y0) * (x - x0) / max(1, x1 - x0)
    return pts[-1][1]


# ---- colours
def _rgb(c):
    return tuple(int(c[i:i + 2], 16) for i in (1, 3, 5))


def mix(c1, c2, t):
    """Blend hex colour c1 toward c2 (t = 0 gives c1, t = 1 gives c2)."""
    a, b = _rgb(c1), _rgb(c2)
    return "#%02x%02x%02x" % tuple(int(a[i] + (b[i] - a[i]) * t) for i in range(3))


def gradient(stops, n):
    """n hex colours interpolated across the list of hex stops."""
    out = []
    for i in range(n):
        t = i / (n - 1) * (len(stops) - 1)
        k = min(int(t), len(stops) - 2)
        out.append(mix(stops[k], stops[k + 1], t - k))
    return out


# ---- clock
def minutes(hhmm):
    h, m = hhmm.split(":")
    return int(h) * 60 + int(m)


def clock_text(mins):
    m = int(mins) % 1440
    return "%02d:%02d" % (m // 60, m % 60)


# ---- noise (the world must not change by itself, so everything is hashed)
def rnd(n):
    """Deterministic pseudo-random float 0..1 for an integer n."""
    n = (n * 374761393 + 668265263) & 0xFFFFFFFF
    n = ((n ^ (n >> 13)) * 1274126177) & 0xFFFFFFFF
    return ((n ^ (n >> 16)) & 0xFFFF) / 65535.0


def smooth(x, seed, step):
    """Value noise that repeats every WORLD columns (so turning 360 loops)."""
    cells = WORLD // step
    i, f = (x // step) % cells, (x % step) / step
    f = f * f * (3 - 2 * f)
    a, b = rnd(i * 977 + seed), rnd(((i + 1) % cells) * 977 + seed)
    return a + (b - a) * f


def terrain(x, seed, step=10):
    return (0.7 * smooth(x, seed, step)
            + 0.3 * smooth(x, seed + 31, max(step // 2, 1)))
