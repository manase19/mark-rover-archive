"""Full-screen effects: scan-line wipe, fading text, terminal typewriter."""
from gfx import fx, rect, screen, txt
from util import gradient


def wipe(done, bars=15, step_ms=35):
    """Black scan-line wipe, top to bottom, then call done()."""
    bh = 600 // bars

    def tick(i=0):
        if i < bars:
            rect(fx, -400, 300 - (i + 1) * bh, 800, bh + 1, "black")
            screen.update()
            screen.ontimer(lambda: tick(i + 1), step_ms)
        else:
            done()
    tick()


def fade_text(lines, y, font, fg, done=None, fade_out=False, step_ms=140, steps=8):
    """Centred text that fades in from black (or out to black)."""
    colors = gradient(["#000000", fg], steps)
    if fade_out:
        colors.reverse()

    def tick(i=0):
        if i < len(colors):
            txt.clear()
            txt.color(colors[i])
            for k, line in enumerate(lines):
                txt.goto(0, y - k * 30)
                txt.write(line, align="center", font=font)
            screen.update()
            screen.ontimer(lambda: tick(i + 1), step_ms)
        else:
            if fade_out:
                txt.clear()
                screen.update()
            if done:
                done()
    tick()


def type_lines(lines, x, y, font, color, done, speed=30, gap=400, line_h=26):
    """Left-aligned terminal typewriter."""
    pos = [0, 0]                       # [line index, chars shown]
    txt.color(color)

    def tick():
        li, ci = pos
        txt.clear()
        for k in range(min(li, len(lines))):
            txt.goto(x, y - k * line_h)
            txt.write(lines[k], font=font)
        if li >= len(lines):
            screen.update()
            done()
            return
        ci += 1
        txt.goto(x, y - li * line_h)
        txt.write(lines[li][:ci] + "_", font=font)
        screen.update()
        if ci >= len(lines[li]):
            pos[0], pos[1] = li + 1, 0
            screen.ontimer(tick, gap)
        else:
            pos[1] = ci
            screen.ontimer(tick, speed)
    tick()
