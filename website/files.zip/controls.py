"""Input: click to walk forward, B / Down to look back at the lander."""
from config import FORWARD_PAN, COLS, FORWARD_MSGS, JUMP_AT, PAN_FRAMES, RIDGE_AT, WORLD
from gfx import screen
from render import draw_all
from state import state
from story import reach_ridge, timelapse
from walk import walk_to


def advance():
    n = state["steps"] + 1
    state["steps"] = n
    state["busy"] = True
    walk_to(n, lambda: arrive(n))


def arrive(n):
    """The leg is finished: show the step's message and trigger story beats."""
    state["msg"] = FORWARD_MSGS[n]
    if n == RIDGE_AT:
        reach_ridge()
        return
    state["busy"] = n == JUMP_AT          # the jump takes over; otherwise hand control back
    draw_all()
    if n == JUMP_AT:
        screen.ontimer(timelapse, 1500)


def sweep(target):
    """Turn the view 180 degrees in a few frames (the hidden look-back)."""
    state["busy"] = True
    state["look"] = target
    start = state["pan"]
    goal = (target - COLS // 2) % WORLD
    delta = ((goal - start + 180) % WORLD) - 180
    state["msg"] = "System: Rotating chassis..."

    def tick(i=1):
        state["pan"] = int(round(start + delta * i / PAN_FRAMES)) % WORLD
        last = i == PAN_FRAMES
        if last:
            state["msg"] = ("System: Landing craft in range. Hatch open. Telemetry: no response."
                            if target else "System: Heading restored.")
            state["busy"] = False
        draw_all()
        if not last:
            screen.ontimer(lambda: tick(i + 1), 60)
    tick()


def look_back():
    if state["busy"] or state["steps"] >= RIDGE_AT:
        return
    sweep(180 if state["look"] == 0 else 0)


def on_click(x, y):
    if state["busy"]:
        return
    if state["look"] != 0:            # a click snaps the view forward again
        state["look"] = 0
        state["pan"] = FORWARD_PAN
    advance()
