"""The HUD: top status bar, message bar and the click hint."""
from config import COLS, INK, DIM, OCHRE, SHOW_ODOMETER, WORLD
from gfx import rect, ui
from state import state
from util import clock_text


def draw_hud(hints=None):
    """hints=None shows the click hint whenever nothing is animating."""
    if hints is None:
        hints = not state["busy"]
    ui.clear()
    rect(ui, -400, 268, 800, 32, INK)
    rect(ui, -400, -300, 800, 44, INK)
    rect(ui, -400, -258, 800, 2, DIM)
    ui.color(OCHRE)
    f = ("Courier", 12, "bold")
    ui.goto(-388, 274)
    ui.write("MARS-OPS // SENSORY LOG", font=f)
    ui.goto(0, 274)
    ui.write("HDG %03d" % ((state["pan"] + COLS // 2) % WORLD), align="center", font=f)
    if SHOW_ODOMETER:
        ui.goto(225, 274)
        ui.write("ODOM %04d m" % state["odo"], align="right", font=f)
    ui.goto(388, 274)
    ui.write("SOL 0001  " + clock_text(state["clock_min"]), align="right", font=f)
    ui.goto(-388, -290)
    ui.write("> " + state["msg"], font=("Courier", 13, "bold"))
    if hints:
        rect(ui, -140, 234, 280, 24, INK)
        ui.color(OCHRE)
        ui.goto(0, 238)
        ui.write("[ CLICK TO ADVANCE ]" if state["look"] == 0
                 else "[ CLICK TO FACE FORWARD ]", align="center", font=f)
