"""Story beats: boot text, the timelapse jump, the ridge, the vista, the end card."""
from config import BOOT, DIM, FINAL_LINES, FONT, OCHRE, POST_JUMP_CLOCK
from effects import fade_text, type_lines, wipe
from gfx import fx, screen, txt
from render import draw_all, draw_vista_frame
from state import state
from storm import set_storm
from util import minutes


def begin():
    type_lines(BOOT, -370, 200, FONT, OCHRE,
               lambda: screen.ontimer(start_walk, 1600))


def start_walk():
    txt.clear()
    set_storm(True)
    state["busy"] = False
    draw_all()


def timelapse():
    """Full-screen time jump, then the lighting shifts."""
    big = ("Courier", 24, "bold")
    msg = ["[ 2 HOURS OF WALKING LATER... ]"]
    set_storm(False)

    def resume():
        fx.clear()
        txt.clear()
        state.update(pal="afternoon", clock_min=minutes(POST_JUMP_CLOCK),
                     msg="System: Elapsed time and odometer do not agree.", busy=False)
        set_storm(True)
        draw_all()

    def hold():
        screen.ontimer(lambda: fade_text(msg, 10, big, OCHRE, resume, True), 1800)

    wipe(lambda: fade_text(msg, 10, big, OCHRE, hold))


def reach_ridge():
    state["busy"] = True
    draw_all()
    screen.ontimer(to_vista, 1200)


def to_vista():
    set_storm(False)
    wipe(lambda: screen.ontimer(show_vista, 700))


def show_vista():
    fx.clear()
    txt.clear()
    state["msg"] = "System: Terrain scan complete. Biosignatures: none."
    draw_vista_frame()
    screen.ontimer(final_lines, 3500)


def final_lines():
    fade_text(FINAL_LINES, -212, ("Courier", 14, "bold"), OCHRE,
              lambda: screen.ontimer(end_card, 5000))


def end_card():
    def show():
        txt.clear()
        fade_text(["[ END OF OPENING SEQUENCE ]"], 0, FONT, DIM)
    wipe(show)
