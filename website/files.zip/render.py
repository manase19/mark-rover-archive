"""Composing a frame: world + HUD (+ storm on top)."""
from gfx import pen, screen
from hud import draw_hud
from state import state
from storm import render_storm
from vista_scene import draw_vista
from walk_scene import draw_walk


def draw_all():
    pen.clear()
    draw_walk()
    draw_hud()
    if state["storm"]:
        render_storm()
    screen.update()


def draw_vista_frame():
    pen.clear()
    draw_vista()
    draw_hud(hints=False)
    screen.update()
