"""Constants, palettes and story text for MARS-OPS.

Everything you are likely to want to tweak lives here.
"""

# ------------------------------------------------------------ screen + world
W, H = 800, 600
P = 8                  # size of one "pixel" block
WORLD = 360            # columns in a full turn: 1 column = 1 degree of heading
COLS = W // P          # 100 columns on screen = a 100-degree field of view
HORIZON = 40           # y of the horizon in the walking scenes

# ------------------------------------------------------------ story beats
JUMP_AT = 4            # forward click that triggers the timelapse
RIDGE_AT = 6           # forward click that reaches the canyon edge
SUN_COL = 340          # heading of the sun
LANDER_COL = 180       # heading of the landing craft (directly behind you)
FORWARD_PAN = (0 - COLS // 2) % WORLD
SLOPE_HALF = 46        # half-width (degrees) of the valley wall ahead
RISE = [0, 0, 10, 28, 46, 66, 86]     # height of the slope after each step
LANDER_U = [8, 7, 6, 5, 4, 3, 2]      # lander pixel size: shrinks as you walk away
PAN_FRAMES = 4         # frames used for the 180-degree turn

# ------------------------------------------------------------ walking animation
# One forward click is one "leg" of the walk. It plays out in real time:
# the ground streams toward you, the hills swell, the slope climbs, the
# odometer and clock run, and the view bobs with every stride.
WALK_SECONDS = 3.6         # how long one leg takes (raise it for a slower walk)
STRIDE_SECONDS = 0.6       # time per footstep (head-bob period)
BOB_PX = 4                 # how far the view dips on each footstep
DEPTH_PER_STEP = 0.6       # how far the ground slides toward you per leg (0..1 = horizon to feet)
LEG_METERS = [0, 120, 140, 160, 180, 200, 260]   # distance of the leg that ends at step n
SHOW_ODOMETER = True       # the ODOM readout in the top bar

# ------------------------------------------------------------ storm
STORM_TICK_MS = 90
MAX_GRAINS = 120

# ------------------------------------------------------------ look
OCHRE, DIM, INK = "#d9a066", "#9a5a30", "#0a0303"
FONT = ("Courier", 15, "bold")

# Hazy butterscotch sky, pale dust on the horizon, orange sand (see references).
PAL = {
    "morning": dict(
        seed=0, sun_h=70,
        sky=["#a9633c", "#c47e52", "#dc9f70", "#ebc196", "#f0cfa8"],
        ground=["#c58652", "#b8774a", "#a86a40", "#8f5430", "#74401f"],
        mesa="#d6a87e", mesa_l="#e3b98e", far="#c08a5e", far_l="#d09c70",
        near="#a8683e", near_l="#c28250",
        slope="#a9663a", slope_l="#cf8d58", strata="#8a5030",
        sun="#fff0d0", glow="#f4d4a4", halo="#e6b888",
        streak="#8a5030", sand="#e0b080", rock_d="#4a2a1e", rock_l="#7a4a36",
        boul=("#d0ae94", "#a68670", "#6f5242", "#5a3322"),
        grain=["#f0d4a8", "#e0b888", "#c89868", "#a87850"]),
    "afternoon": dict(      # "2 hours later": lower sun, redder, darker
        seed=500, sun_h=24,
        sky=["#4a2018", "#8a3c25", "#c0683a", "#e0a068", "#e8b27c"],
        ground=["#9a5430", "#8a4a2a", "#7a3e22", "#5e2e18", "#44200f"],
        mesa="#b87a54", mesa_l="#c88a62", far="#9a5c3a", far_l="#ae6e46",
        near="#7a4026", near_l="#92502e",
        slope="#7e4026", slope_l="#a85e36", strata="#5e2c18",
        sun="#ffc890", glow="#e89050", halo="#c0683a",
        streak="#5e2c18", sand="#b87848", rock_d="#2a140c", rock_l="#5a3020",
        boul=("#a07a64", "#7a5a48", "#4a3428", "#2e1a12"),
        grain=["#d9a070", "#b87848", "#8f5530", "#6a3a20"]),
}

# ------------------------------------------------------------ text
CLOCKS = ["09:12", "09:13", "09:15", "09:16", "09:17", "13:52", "17:41"]
POST_JUMP_CLOCK = "11:17"          # shown right after the timelapse
WALK_MSG = "System: Walking..."
FORWARD_MSGS = [
    "", "System: Terrain nominal. Proceeding.",
    "System: Wind 18 m/s. Audio input: 0 dB.",
    "System: Slope detected ahead. Gradient +9 deg.",
    "System: Gradient +14 deg. Valley wall ahead.",
    "System: Clock resynchronised. Elapsed: 2 h 35 min. Steps taken: 1.",
    "System: Elevation rising...",
]
BOOT = [
    "MARS-OPS // SENSORY LOG v1.05",
    "> link ........ established",
    "> operator ..... [NO DATA]",
    "> location ..... Mars, surface, Sol 0001",
    "> audio ........ no carrier",
    "> click anywhere to advance",
]
FINAL_LINES = ["Four thousand kilometres of canyon. No other footprints.",
               "You are alone here. The silence feels occupied."]
