"""The canyon vista at the end of the sequence (after the reference photo).

Hazy daylight basin, sun upper right, sunlit red cliffs. Nothing man-made.
The rock is angular on purpose: ridgelines are stepped, the faces are layered
strata, and boulders are faceted blocks (see rockface.py).
"""
from config import COLS, DIM, INK, P
from gfx import disc, layer, pen, puff, rect
from rockface import X, chunk, cliff_face, ridge
from util import gradient, q, rnd

V_HORIZON = 60

# (ridge points) are (column, height) pairs; heights are screen y.
MESA_PTS = [(0, 60), (22, 60), (24, 72), (26, 88), (28, 92), (37, 92), (39, 86), (41, 76),
            (43, 66), (44, 60), (47, 60), (49, 70), (52, 78), (54, 74), (56, 66), (58, 60),
            (99, 60)]

MASSIF_PTS = [(0, 40), (43, 40), (44, 60), (48, 70), (51, 88), (54, 100), (57, 118),
              (60, 128), (63, 126), (66, 140), (69, 152), (72, 150), (75, 164), (78, 174),
              (80, 178), (82, 166), (84, 150), (86, 168), (89, 172), (92, 160), (94, 150),
              (96, 170), (99, 186)]

WALL_PTS = [(0, -300), (44, -300), (45, -200), (48, -150), (51, -118), (54, -92), (57, -70),
            (61, -44), (65, -20), (69, 0), (73, 14), (77, 26), (81, 40), (85, 46),
            (88, 56), (92, 60), (95, 70), (99, 80)]

OUTCROP_PTS = [(0, 80), (3, 84), (5, 70), (8, 60), (10, 40), (13, 22), (16, 2), (19, -18),
               (22, -44), (26, -70), (30, -100), (34, -128), (38, -150), (41, -170),
               (44, -192), (46, -300), (99, -300)]

MASSIF = dict(crest="#eab88e", lit="#d98d5e", high="#b86a48", low="#8a4634", dark="#5c2a20",
              seam="#6e342a", gully="#5a2820", haze="#cfa088")
WALL = dict(crest="#e48a5c", lit="#c8663f", high="#a8503a", low="#6e2a1e", dark="#46190f",
            seam="#52211a", gully="#4a1a12", haze="#a06a58")
OUTCROP = dict(crest="#ee9a6c", lit="#d4724a", high="#b8583a", low="#7a2e1c", dark="#4a1a10",
               seam="#5a2216", gully="#4a1a12", haze="#a06a58")
RUST = ("#e28a5c", "#b4562f", "#76301c", "#3e170d")      # faceted boulders: light, mid, dark, shadow


def dune(x, y, w):
    """A wind-carved dune ridge: lit crest over a shadowed lee side."""
    rect(pen, x, y, w, 3, "#f0d8bc")
    rect(pen, x + 8, y - 4, w - 20, 4, "#b98f74")
    rect(pen, x + 24, y - 8, max(8, w - 56), 4, "#c9a088")


def draw_vista():
    # sky + sun (a soft glow built from stacked discs)
    for i, c in enumerate(gradient(["#9c6a5c", "#b98672", "#d6aa8a", "#ecd0b0"], 12)):
        rect(pen, -400, 300 - (i + 1) * 20, 800, 20, c)
    sx, sy = -400 + 69 * P, 178
    for r, c in [(11, "#dcb496"), (8, "#e8c8a8"), (5, "#f4dcc0"), (3, "#fff4dc")]:
        disc(sx, sy, r, c, V_HORIZON)

    # sandy basin floor, ripples and a few long dunes
    for i, c in enumerate(gradient(["#e0c2a6", "#d3ae92", "#bd917a", "#9c6e58"], 14)):
        rect(pen, -400, V_HORIZON - (i + 1) * 20, 800, 20, c)
    for i in range(30):
        d = rnd(i * 5 + 1) ** 1.3
        w = int((3 + rnd(i * 5 + 3) * 6) * P * (1 + d * 2))
        rect(pen, -400 + int(rnd(i * 5 + 2) * COLS) * P, q(V_HORIZON - 8 - d * 250), w,
             3 + int(d * 4), "#ecd2b6" if i % 2 else "#b48a6e")
    dune(-400 + 20 * P, 24, 150)
    dune(-400 + 50 * P, -8, 210)
    dune(-400 + 14 * P, -66, 260)

    # far hazy mesas
    layer(ridge(MESA_PTS, seed=5, jag=4, run=(3, 6)), "#e4cab0", "#d3b49c", P, V_HORIZON)

    # sunlit cliff range on the right, with faded base
    massif = ridge(MASSIF_PTS, seed=3, jag=16, run=(2, 4))
    cliff_face(massif, 52, MASSIF, seed=7, gullies=9, haze_h=56)

    # near wall (right) and rocky outcrop (left)
    wall = ridge(WALL_PTS, seed=13, jag=18, run=(2, 3))
    cliff_face(wall, -300, WALL, seed=21, gullies=6)
    outcrop = ridge(OUTCROP_PTS, seed=29, jag=14, run=(2, 3))
    cliff_face(outcrop, -300, OUTCROP, seed=33, gullies=5)

    # faceted boulders along the crests
    for i in range(9):
        c = int(rnd(i * 7 + 1) * 40)
        if outcrop[c] > -150:
            chunk(X(c) - 8, outcrop[c] - 4, 36 + int(rnd(i * 7 + 2) * 44),
                  24 + int(rnd(i * 7 + 3) * 28), RUST, seed=i)
    for i in range(6):
        c = 49 + int(rnd(i * 11 + 3) * 46)
        if wall[c] > -120:
            chunk(X(c) - 8, wall[c] - 4, 28 + int(rnd(i * 11 + 4) * 30),
                  18 + int(rnd(i * 11 + 5) * 22), RUST, seed=40 + i)

    puff(X(8), 36, 56)                                         # blown dust
    puff(X(38), 4, 44, "#e0bc9e", "#ecd2b6")
    puff(X(84), 66, 70)

    rect(pen, -400, -254, 800, 64, INK)                        # caption strip
    rect(pen, -400, -192, 800, 2, DIM)
