"""The one shared game-state dict."""
from config import CLOCKS, FORWARD_PAN
from util import minutes

state = dict(
    steps=0,                    # forward clicks made (the step we are walking to)
    travel=0.0,                 # how far along the walk we are, in steps (fractional mid-walk)
    odo=0.0,                    # odometer, metres
    clock_min=minutes(CLOCKS[0]),
    pan=FORWARD_PAN,            # heading of the left edge of the view
    look=0,                     # 0 = facing forward, 180 = looking back at the lander
    pal="morning",
    msg="System: Link established.",
    busy=True,                  # True while an animation owns the screen
    storm=False,
    tick=0,
)
